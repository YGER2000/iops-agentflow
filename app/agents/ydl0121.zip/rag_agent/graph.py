import logging
from langgraph.graph import StateGraph, END

from .state import RAGState
from . import nodes

logger = logging.getLogger(__name__)


def build_rag_graph(llm_service, req_client) -> StateGraph:
    """构建 RAG 工作流图

    设计目标（对齐 common_qa 的简洁风格）：
    - 节点清晰：parse_input → rewrite_query → req_search → compose_answer → END
    - 依赖注入：通过 nodes.set_* 注入 llm_service/req_client
    - 方便 debug：节点内提供详细日志
    """
    logger.info("[graph] building rag graph...")
    nodes.set_llm_service(llm_service)
    nodes.set_req_client(req_client)

    workflow = StateGraph(RAGState)

    workflow.add_node("parse_input", nodes.parse_input_node)
    workflow.add_node("rewrite_query", nodes.rewrite_query_node)
    workflow.add_node("req_search", nodes.req_search_node)
    workflow.add_node("compose_answer", nodes.compose_answer_node)

    workflow.set_entry_point("parse_input")

    workflow.add_edge("parse_input", "rewrite_query")
    workflow.add_edge("rewrite_query", "req_search")
    workflow.add_edge("req_search", "compose_answer")
    workflow.add_edge("compose_answer", END)

    logger.info("[graph] rag graph ready")
    return workflow

